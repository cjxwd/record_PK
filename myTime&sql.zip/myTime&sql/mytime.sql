/*==============================================================*/
/* DBMS name:      MySQL 5.0                                    */
/* Created on:     2015/5/29 5:43:02                            */
/*==============================================================*/


drop table if exists date;

drop table if exists student;

drop table if exists time;

/*==============================================================*/
/* Table: date                                                  */
/*==============================================================*/
create table date
(
   date                 date not null,
   studentID            int,
   primary key (date)
);

/*==============================================================*/
/* Table: student                                               */
/*==============================================================*/
create table student
(
   studentID            int not null,
   studentName          varchar(20) not null,
   primary key (studentID)
);

/*==============================================================*/
/* Table: time                                                  */
/*==============================================================*/
create table time
(
   time                 int not null,
   date                 date,
   event                varchar(50),
   primary key (time)
);

alter table date add constraint FK_Relationship_2 foreign key (studentID)
      references student (studentID) on delete restrict on update restrict;

alter table time add constraint FK_Relationship_1 foreign key (date)
      references date (date) on delete restrict on update restrict;


package functions;
import java.sql.*;
import java.sql.Statement;

import com.mysql.jdbc.*;
import com.mysql.jdbc.Connection;
import com.mysql.jdbc.PreparedStatement;

import db.JDBC;

public class Register_Util {
	public boolean hasRegister(Student_Bean addstudent){
	Connection conn = null;
	Statement stmt=null;
	ResultSet rs=null;
	
    try {
		conn = (Connection)JDBC.getConnection();
		System.out.println("");
		stmt=conn.createStatement();
		
	} 
    catch (Exception e) {
		e.printStackTrace();
	}
    int studentid=addstudent.getStudentID();
    String a=Integer.toString(studentid);
    String sql="select * from student where studentID="+a;
    try{
    	rs=stmt.executeQuery(sql);
    }
    catch(Exception e){
    	return true;
    	//e.printStackTrace();
    }
    try{
    	rs.close();
    	stmt.close();
    }
    catch(Exception e){
    	e.printStackTrace();
    	
    }
    return false;
    

}
}

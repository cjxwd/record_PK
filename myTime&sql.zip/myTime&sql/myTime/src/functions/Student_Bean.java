package functions;

public class Student_Bean {
	private static int studentID;
	public static int getStudentID() {
		return studentID;
	}
	public static void setStudentID(int studentID) {
		Student_Bean.studentID = studentID;
	}
	public static String getStudentName() {
		return studentName;
	}
	public static void setStudentName(String studentName) {
		Student_Bean.studentName = studentName;
	}
	private static String studentName;

}

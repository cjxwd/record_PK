package functions;
import java.sql.*;
import java.sql.PreparedStatement;
import java.sql.Statement;

import com.mysql.jdbc.*;
import com.mysql.jdbc.Connection;

import db.JDBC;

public class Login_Util {
	public boolean hasLogin(Student_Bean addstudent)
	{
		Connection conn = null;
		
		PreparedStatement stmt=null;
		ResultSet rs=null;
		
	    try {
			conn = (Connection)JDBC.getConnection();
			System.out.println("");
			//stmt=conn.createStatement();
			
		} 
	    catch (Exception e) {
			e.printStackTrace();
		}
	    int studentid=addstudent.getStudentID();
	    String studentname=addstudent.getStudentName();
	    String a=Integer.toString(studentid);
	    String sql="insert into student values(?,?)";
	    try{
	    	stmt=conn.prepareStatement(sql);
	    	stmt.setInt(1,studentid);
	    	stmt.setString(2, studentname);
	    	stmt.execute();
	    }
	    catch(Exception e){
	    	//return true;
	    	e.printStackTrace();
	    }
	    try{
	    	//rs.close();
	    	stmt.close();
	    }
	    catch(Exception e){
	    	e.printStackTrace();
	    	
	    }
	    return false;
	}

}

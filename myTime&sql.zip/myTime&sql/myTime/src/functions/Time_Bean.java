package functions;

public class Time_Bean {
	private int time;
	public int getTime() {
		return time;
	}
	public void setTime(int time) {
		this.time = time;
	}
	public String getEvent() {
		return event;
	}
	public void setEvent(String event) {
		this.event = event;
	}
	private String event;
	private int date;
	public int getDate() {
		return date;
	}
	public void setDate(int date) {
		this.date = date;
	}

}

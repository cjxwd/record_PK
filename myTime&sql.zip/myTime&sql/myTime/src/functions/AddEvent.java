package functions;

import java.sql.*;
import java.sql.PreparedStatement;
import java.sql.Statement;

import com.mysql.jdbc.*;
import com.mysql.jdbc.Connection;

import db.JDBC;

public class AddEvent {
	public boolean hasAddEvent(Time_Bean addtime)
	{
		Connection conn = null;
		PreparedStatement stmt=null;
		ResultSet rs=null;
		
	    try {
			conn = (Connection)JDBC.getConnection();
			System.out.println("");
			//PreparedStatement stmt=null;
			
		} 
	    catch (Exception e) {
			e.printStackTrace();
		}
	    int date=addtime.getDate();
	    String a=Integer.toString(date);
	    String event=addtime.getEvent();
	    int time=addtime.getTime();
	    String b=Integer.toString(time);
	    String sql="insert into time values (?,?,?)";
	    try{
	    	stmt=conn.prepareStatement(sql);
	    	//stmt.setInt(1,1);
	    	//stmt.setInt(3,2);
	    	//stmt.setString(2,"sdfsdf");
	    	stmt.setInt(1,time);
	    	stmt.setInt(3,date);
	    	stmt.setString(2,event);
	    	stmt.execute();
	    	//stmt.setString(2,event);
	    	//System.out.println("has read");
	    }
	    catch(Exception e){
	    	//return true;
	    	e.printStackTrace();
	    }
	    try{
	    	//rs.close();
	    	//JDBC.release(rs);
	    	stmt.close();
	    }
	    catch(Exception e){
	    	e.printStackTrace();
	    	
	    }
	    return false;
	}

}

package functions;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.*;

import com.mysql.jdbc.Connection;

import db.JDBC;

public class Search {
	//private ArrayList line;
	private Object line[][]=new Object[20][3];
	private int index;
	
	
	public int getIndex() {
		return index;
	}
	public void setIndex(int index) {
		this.index = index;
	}
	public Object[][] getLine() {
		return line;
	}
	public void setLine(Object[][] line) {
		this.line = line;
	}
	public boolean hasSearchD(Time_Bean addtime){
		Connection conn = null;
		PreparedStatement stmt=null;
		ResultSet rs=null;
		
	    try {
			conn = (Connection)JDBC.getConnection();
			System.out.println("");
			//PreparedStatement stmt=null;
			
		} 
	    catch (Exception e) {
			e.printStackTrace();
		}
	    int date=addtime.getDate();
	    String a=Integer.toString(date);
	    String event=addtime.getEvent();
	    int time=addtime.getTime();
	    String b=Integer.toString(time);
	    System.out.println("done11");
	    String sql="select * from time where date=?";
	   
	    
	    try{
	    	//stmt.setInt(3,201511);
	    	stmt=conn.prepareStatement(sql);
	    	System.out.println("done12");
	    	rs=stmt.executeQuery();
	    	//stmt.setInt(1,date);
	    	//stmt.setInt(3,date);
	    	//stmt.setString(1,event);
	    	//stmt.setString(2,event);
	    	//rs=stmt.executeQuery();
	    	//stmt.execute();
	    	System.out.println("done1");
	        //index=2;
	    	index=0;
	    	System.out.println(rs.getInt(1));
	    	do
	    	{
	    		System.out.println("done2");
	    		int j=0;
	    		{
	    		
	    		//line[index][j]=rs.getInt(1);
	    			System.out.println(rs.getInt(1));
	    		j++;
	    		//line[index][j]=rs.getString(2);
	    		j++;
	    		//line[index][j]=rs.getInt(3);
	    		//j++;
	    		index++;
	    		//setIndex(index);
	    		System.out.println("done");
	    		}
	    	}while(rs.next());
	        //line[][]={{1,2,3},{},{}};
	        
	    }
	    catch(Exception e){
	    	//return true;
	    	e.printStackTrace();
	    }
	    try{
	    	//rs.close();
	    	stmt.close();
	    }
	    catch(Exception e){
	    	e.printStackTrace();
	    	
	    }
	    return false;
	    

	}
	public boolean hasSearchS(Student_Bean adddate){
		Connection conn = null;
		Statement stmt=null;
		ResultSet rs=null;
		
	    try {
			conn = (Connection)JDBC.getConnection();
			System.out.println("");
			stmt=conn.createStatement();
			
		} 
	    catch (Exception e) {
			e.printStackTrace();
		}
	    int ID=adddate.getStudentID();
	    String a=Integer.toString(ID);
	    String sql="select * from student where studentID="+a;
	    String mr=null;
	    try{
	    	rs=stmt.executeQuery(sql);
	    	while(rs.next()){
	    		mr+=rs.getNString("studentName")+"\n";
	    	}
	    	String searchResult=mr;
	    	
	    }
	    catch(Exception e){
	    	return true;
	    	//e.printStackTrace();
	    }
	    if(mr==null)
	    	return true;
	    try{
	    	rs.close();
	    	stmt.close();
	    }
	    catch(Exception e){
	    	e.printStackTrace();
	    	
	    }
	    return false;
	    

	}

}

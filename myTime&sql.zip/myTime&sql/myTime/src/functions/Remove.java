package functions;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import com.mysql.jdbc.Connection;

import db.JDBC;

public class Remove {
	public boolean hasremove(Time_Bean addtime)
	{
		Connection conn = null;
		PreparedStatement stmt=null;
		ResultSet rs=null;
		
	    try {
			conn = (Connection)JDBC.getConnection();
			System.out.println("");
			//PreparedStatement stmt=null;
			
		} 
	    catch (Exception e) {
			e.printStackTrace();
		}
	    int date=addtime.getDate();
	    String a=Integer.toString(date);
	    String event=addtime.getEvent();
	    int time=addtime.getTime();
	    String b=Integer.toString(time);
	    String sql="delete from time where time=?";
	    try{
	    	stmt=conn.prepareStatement(sql);
	    	stmt.setInt(1,time);
	    	stmt.execute();
	    	//stmt.setInt(3,date);
	    	//stmt.setString(2,event);
	    	//stmt.setString(2,event);
	    }
	    catch(Exception e){
	    	return true;
	    	//e.printStackTrace();
	    }
	    try{
	    	//rs.close();
	    	stmt.close();
	    }
	    catch(Exception e){
	    	e.printStackTrace();
	    	
	    }
	    return false;
	}

}
